# Install the Codex edition

1. Unzip `clean-my-ai-harness-codex.zip`.
2. Copy `skills/clean-my-ai-harness-codex` into your repository's `.agents/skills/` folder.
3. Open or restart Codex in that repository.
4. Say:

> $clean-my-ai-harness-codex review the AI setup for this repository. Start read-only. Show me one plain-English report. Do not change anything until I approve each change.

The first run changes nothing. The report will say what Codex could not see.

To remove the cleaner, delete `.agents/skills/clean-my-ai-harness-codex`. That does not undo changes you previously approved; use the rollback instructions from that run.
