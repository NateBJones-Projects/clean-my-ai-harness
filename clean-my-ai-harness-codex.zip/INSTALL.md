# Install the Codex edition

**Requires Python 3.10 or newer.** Check with `python3 --version`. The report builder uses 3.10+ features and will fail on older Python.

1. Unzip `clean-my-ai-harness-codex.zip`.
2. Copy the `clean-my-ai-harness-codex` folder into `~/.codex/skills/` (create that folder if it does not exist). This is the folder Codex loads skills from.
3. Restart Codex. The skill is now available by name. (It may not appear in the `$` autocomplete list — invoking it by name works regardless.)
4. Open the repository you want to review and paste this, naming the skill directly:

> $clean-my-ai-harness-codex review the AI setup for this repository. Run your read-only scanner and generate the report. Read-only means do not modify my existing files, but you should run the scan and create the report. Do not apply any change until I approve it.

The first run changes nothing in your repository. The report (`YOUR-AI-SETUP.html`) is written to a folder beside it, and it says what Codex could not see.

To remove the cleaner, delete `~/.codex/skills/clean-my-ai-harness-codex`. That does not undo changes you already approved; use that run's rollback.
